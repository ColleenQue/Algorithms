/*******************************************************************************
 * Name        : stairclimber.cpp
 * Author      : Colleen Que
 * Date        : October 2, 2021
 * Description : Lists the number of ways to climb n stairs.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iomanip>

using namespace std;

vector< vector<int> > get_ways(int num_stairs) {
    // TODO: Return a vector of vectors of ints representing
    // the different combinations of ways to climb num_stairs
    // stairs, moving up either 1, 2, or 3 stairs at a time.
    vector <vector<int>> ways;
    vector <vector<int>> result;
    vector<int> n;

    if (num_stairs<=0){
        ways.push_back(n);
        return ways; // vector with 0 in it
    }

    //for i = 1 2 3
    for(int i =1;i<4;i++){
        //recursion happens if num stairs is big enough
        if(num_stairs>=i) {
            result = get_ways(num_stairs-i);
        

        //prepend i to all solutions in result
        for(size_t j =0; j<result.size();j++){
            //result[j] is a vector
            result[j].insert(result[j].begin(),i);
        }

         for(size_t k =0; k<result.size();k++){
            //result[k] is a vector
            ways.push_back(result[k]);
        }
        }
    }

   
    return ways;

}

void display_ways(const vector< vector<int> > &ways) {
    // TODO: Display the ways to climb stairs by iterating over
    // the vector of vectors and printing each combination.

    //right aligned according to largest number

    
    int max_digit = 1;
    int count = ways.size(); //count is length of ways

    while(count/10>=1){
        count = count/10;
        max_digit ++;
    }

    //cout<<ways.size()<<endl;
    for(size_t i=0; i<ways.size();i++){

        cout<<setw(max_digit) << i+1<<". [";

        //print the individual numbers

        //doesnt iterate if ways[i].size<=1
        for (size_t j=0; j<ways[i].size()-1;j++){
            cout<<ways[i][j]<<", ";
        }

        //last element without the comma
        cout<< ways[i][ways[i].size()-1]<<"]"<<endl;

    }


}

int main(int argc, char * const argv[]) {

istringstream iss; 
int num;
if (argc!=2){
    cerr << "Usage: " << argv[0] << " <number of stairs>" << endl;
    return 1;  
}


iss.str(argv[1]);

    if (!(iss >> num))
    {
        cerr << "Error: Number of stairs must be a positive integer." << endl;
        return 1;
    }

    if(num<1)
    {
        cerr << "Error: Number of stairs must be a positive integer." << endl;
        return 1;
    }




    //int num_ways = get_ways(num).size();
    cout<<get_ways(num).size();

    if (num == 1){
        cout<<" way to climb "<<num<<" stair."<<endl;
    }
    else{
    cout<<" ways to climb "<<num<<" stairs."<<endl;
    }


    display_ways(get_ways(num));
return 0;

}
