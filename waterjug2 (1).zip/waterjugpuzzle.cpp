/*******************************************************************************
 * Name        : waterjugpuzzle.cpp
 * Author      : Fenella Anne Lachica and Colleen Que
 * Date        : 10.16.21
 * Description : Pour water into different jugs until getting desired water lmao.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/


#include <iostream>
#include <sstream>
#include <string>
#include <queue>
#include <vector>
#include <stack>

using namespace std;

// Struct to represent state of water in the jugs.
struct State
{
    int a, b, c;
    string directions;
    State *parent;

    State(int _a, int _b, int _c, string _directions) : a{_a}, b{_b}, c{_c}, directions{_directions}, parent{nullptr} {}
    // String representation of state in tuple form.
    string to_string()
    {
        ostringstream oss;
        oss << "(" << a << ", " << b << ", " << c << ")";
        return oss.str();
    }
};



//return list for bfs
string bfs(State *capacity, State *initial, State *goal)
{

	string result = "";
	queue<State*> q;
  vector<State*> memory={};
	q.push(initial); // add current to queue
	bool **store = new bool*[capacity->a+1];
	
	for(int i =0;i<capacity->a+1;i++){
		store[i] = new bool[capacity -> b+1];
		fill(store[i],store[i]+capacity ->b+1,false);
	}

   State* current;

	while (!q.empty())
	{
 
        current = q.front();
        q.pop();

        stack<string> s;
		//if goal achieved
		if ((current->a == goal->a) && (current->b == goal->b))
		{
			while (current!= NULL)
			{
                s.push(current->directions +" " + current->to_string());
				current = current->parent;
			}

            while(s.size()!=1){
                result+= s.top()+"\n";
                s.pop();
            }
            result+= s.top();
            delete current;
               
	    for(int i =0;i<capacity->a+1;i++){
	      	delete [] store[i];
      	}
  
    delete [] store;
    
   
    for (size_t i=0;i<memory.size();i++){
        delete memory[i];
    }
			return result;
		}
		//if current has been seen

		if (store[current->a][current->b] == 1)
		{
			continue;
		}
        
		store[current->a][current->b] = 1; // mark visited

		//conditionals: 1. destination!=capacity 2. source!=0
		//1. c -->a

		int water, aa, bb, cc;
		if ((capacity->a != current->a) && (current->c != 0))
		{

			if ((current->a + current->c) > (capacity->a))
				//case in which we pour water until destination is filled
			{
				water = capacity->a - current->a;
				aa = capacity->a;
			}
			else
			{
				water = current->c;
				aa = current->c + current->a;
			}
			string str;
			if(water ==1){
				str = "Pour " + to_string(water)+ " gallon from C to A.";
			}
			else{
				str = "Pour " +  to_string(water)+ " gallons from C to A.";
			}
			cc = current->c - water;
			bb = current->b;

			State *s = new State(aa, bb, cc, str);
			s->parent = current;
			//do something about parent
			q.push(s);
      memory.push_back(s);
			//cout << "c -> a " << s->to_string() << " " << s->parent->to_string() << endl;
		}

		//conditional: 1. destination!=capacity 2. source!=0
		//2. b ->a
		if ((capacity->a != current->a) && (current->b != 0))
		{

			if ((current->a + current->b) > (capacity->a))
				//case in which we pour water until destination is filled
			{
				water = capacity->a - current->a;
				aa = capacity->a;
			}
			else
			{
				water = current->b;
				aa = current->b+ current->a;
			}
			string str;
			if(water ==1){
				str = "Pour " +  to_string(water)+ " gallon from B to A.";
			}
			else{
				str = "Pour " + to_string(water) + " gallons from B to A.";
			}
			bb = current->b - water;
			cc = current->c;

			State *s = new State(aa, bb, cc, str);
			s->parent = current;
			//do something about parent
			q.push(s);
            memory.push_back(s);
			//cout << "b -> a " << s->to_string() << " " << s->parent->to_string() << endl;
		}

		//3. c --> b
		if ((capacity->b != current->b) && (current->c != 0))
		{

			if ((current->c + current->b) > (capacity->b))
				//case in which we pour water until destination is filled
			{
				water = capacity->b - current->b;
				bb = capacity->b;
			}
			else
			{
				water = current->c;
				bb = current->b + current->c;
			}

			cc = current->c - water;
			aa = current->a;

			string str;
			if(water ==1){
				str = "Pour " +  to_string(water) + " gallon from C to B.";
			}
			else{

				str = "Pour " + to_string(water) + " gallons from C to B.";
			}

			State *s = new State(aa, bb, cc, str);
			s->parent = current;
			//do something about parent
			q.push(s);
            memory.push_back(s);
			//cout << "c -> b " << s->to_string() << " " << s->parent->to_string() << endl;
		}

		//4. a --> b
		if ((capacity->b != current->b) && (current->a != 0))
		{

			if ((current->a + current->b) > (capacity->b))
				//case in which we pour water until destination is filled
			{
				water = capacity->b - current->b;
				bb = capacity->b;
			}
			else
			{
				water = current->a;
				bb = current->b + current->a;
			}
			string str;
			if(water ==1){
				str = "Pour " +  to_string(water) + " gallon from A to B.";
			}
			else{
				str = "Pour " + to_string(water) + " gallons from A to B.";
			}
			aa = current->a - water;

			cc = current->c;

			State *s = new State(aa, bb, cc, str);
			s->parent = current;
			//do something about parent
			q.push(s);
            memory.push_back(s);
			//cout << "a->b " <<  s->to_string() << " " << s->parent->to_string() << endl;
		}

		//5. b --> c
		if ((capacity->c != current->c) && (current->b != 0))
		{

			if ((current->c + current->b) > (capacity->c))
				//case in which we pour water until destination is filled
			{
				water = capacity->c - current->c;
				cc = capacity->c;
			}
			else
			{
				water = current->b;
				cc = current->c + current->b;
			}
			string str;
			if(water ==1){
				str = "Pour " +  to_string(water) + " gallon from B to C.";
			}
			else{
				str = "Pour " + to_string(water) + " gallons from B to C.";
			}
			bb = current->b - water;
			aa = current->a;

			State *s = new State(aa, bb, cc, str);
			s->parent = current;
			//do something about parent
			q.push(s);
            memory.push_back(s);
			//cout << "b -> c " << s->to_string() << " " << s->parent->to_string() << endl;
		}

		//6. a--> c
		if ((capacity->c != current->c) && (current->a != 0))
		{

			if ((current->c + current->a) > (capacity->c))
				//case in which we pour water until destination is filled
			{
				water = capacity->c - current->c;
				cc = capacity->c;
			}
			else
			{
				water = current->a;
				cc= current->c + current->a;
			}

			string str;
			if(water ==1){
				str = "Pour " +  to_string(water) + " gallon from A to C.";
			}
			else{
				str = "Pour " + to_string(water) + " gallons from A to C.";}
			aa = current->a - water;
			bb = current->b;

			State *s = new State(aa, bb, cc, str);
			s->parent = current;
			//do something about parent
			q.push(s);
            memory.push_back(s);
			//cout << "a -> c " << s->to_string() << " " << s->parent->to_string() << endl;
            //delete current;
		}
	}




   
	for(int i =0;i<capacity->a+1;i++){
		delete [] store[i];
	}
    delete [] store;


   
    for (size_t i=0;i<memory.size();i++){
        delete memory[i];
    }
   

    //delete current;

	return "No solution.";

}

//vector doesnt work on here but works on ubuntu
int main(int argc, char *argv[])
{
    int cA = 0;
    int cB = 0;
    int cC = 0;
    int gA = 0;
    int gB = 0;
    int gC = 0;
    vector<int> jugs = {cA, cB, cC, gA, gB, gC};
    char jug_name[3] = {'A', 'B', 'C'};
    istringstream iss;

    if (argc != 7)
    {
        cerr << "Usage: " << argv[0] << " <cap A> <cap B> <cap C> <goal A> <goal B> <goal C>" << endl;
        return 1;
    }

    for (int i = 1; i < argc; i++)
    {
        iss.str(argv[i]);

        //check if capacity is valid
        if (i < 4)
        {
            if (!(iss >> jugs[i - 1]) or (jugs[i-1]<1))
            {
                cerr << "Error: Invalid capacity '" << argv[i] << "' for jug " << jug_name[i - 1] <<"."<< endl;
                return 1;
            }
        }

        //check if goal is valid
        if (i > 3)
        {
            if (!(iss >> jugs[i - 1]) or (jugs[i-1]<0))
            {
                cerr << "Error: Invalid goal '" << argv[i] << "' for jug " << jug_name[i - 4] << "."<<endl;
                return 1;
            }
        }


        iss.clear();
    }

    vector<int> cap = {jugs[0], jugs[1], jugs[2]};
    vector<int> goal = {jugs[3], jugs[4], jugs[5]};

    for (size_t i = 0; i < goal.size(); i++)
    {
        if (goal[i] > cap[i])
        {
            cerr << "Error: Goal cannot exceed capacity of jug " << jug_name[i] << "."<<endl;
            return 1;
        }
    }

    int total_goal = goal[0] + goal[1] + goal[2];
    if (total_goal != cap[2])
    {
        cerr << "Error: Total gallons in goal state must be equal to the capacity of jug C." << endl;
        return 1;
    }

    //string bfs(State *capacity, State *current, State *goal)
	State *caps = new State (jugs[0],jugs[1],jugs[2], "capacity");
    State *initials = new State(0, 0, jugs[2], "Initial state.");
    State *goals = new State (goal[0],goal[1],goal[2],"goal");


    cout<<bfs(caps,initials,goals)<<endl;


    delete goals;
    delete caps;
    delete initials;

    return 0;
    
}