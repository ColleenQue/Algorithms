/*******************************************************************************
 * Name        : inversioncounter.cpp
 * Author      : Colleen Que
 * Version     : 1.0
 * Date        : October 30,2021
 * Description : Counts the number of inversions in an array.
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 ******************************************************************************/
#include <iostream>
#include <algorithm>
#include <sstream>
#include <vector>
#include <cstdio>
#include <cctype>
#include <cstring>

using namespace std;

// Function prototype.
static long mergesort(int array[], int scratch[], int low, int high);

/**
 * Counts the number of inversions in an array in theta(n^2) time.
 */
long count_inversions_slow(int array[], int length) {
    // TODO
    long output=0;
    for(int i =0;i<length;i++){
        for(int j =i;j<length;j++){
        //for everything after i
        if(array[j]<array[i]){
            output+=1;
        }
        }
    }
    return output;
}

/**
 * Counts the number of inversions in an array in theta(n lg n) time.
 */
long count_inversions_fast(int array[], int length) {
    // TODO
    // Hint: Use mergesort!
    int* scratch = new int[length];
    for(int i =0;i<length;i++){
        scratch[i]=0;
    }
    
    long output = mergesort(array,scratch,0,length-1);
    delete [] scratch;
    return output;


}

static long mergesort(int array[], int scratch[], int low, int high) {
    // TODO

    long output =0;
    if (low<high){
        int mid = low + (high - low)/2;
        output += mergesort (array, scratch, low,mid);
        output += mergesort(array, scratch, mid+1, high);
        int L = low;
        int H = mid + 1;

        for (int k = low;k<=high;k++){

            if (L<=mid && (H>high or array[L]<=array[H])){
                scratch[k] = array[L];
                L = L+1;
            }
            else{
                scratch[k] = array[H];
                H = H+1;
                output += mid -L+1;
            }
        }

        for (int k = low;k<=high;k++){
            array[k] = scratch[k];
        }
    }
    return output;
}

int main(int argc, char *argv[]) {
    // TODO: parse command-line argument

   //cout<<"argc "<< argc <<endl;
    if(argc!=1 && argc!=2){

        cerr<<"Usage: ./inversioncounter [slow]"<<endl;
        return 1;
    }



    istringstream iss;
    string option;

    if(argc!=1){
    iss.str(argv[1]);
    if(!(iss>>option)){
        cerr<<"Usage: ./inversioncounter [slow]"<<endl;
        return 1;
    }
    iss.clear();
    
    
         if(option!="slow"){

         cerr<<"Error: Unrecognized option '"<< option <<"'."<<endl;
         return 1;
    }
    }


    cout << "Enter sequence of integers, each followed by a space: " << flush;

   // istringstream iss;
    int value, index = 0;
    vector<int> values;
    string str;
    str.reserve(11);
    char c;
    while (true) {
        c = getchar();
        const bool eoln = c == '\r' || c == '\n';
        if (isspace(c) || eoln) {
            if (str.length() > 0) {
                iss.str(str);
                if (iss >> value) {
                    values.push_back(value);
                } else {
                    cerr << "Error: Non-integer value '" << str
                         << "' received at index " << index << "." << endl;
                    return 1;
                }
                iss.clear();
                ++index;
            }
            if (eoln) {
                break;
            }
            str.clear();
        } else {
            str += c;
        }
    }
/*
run_test_args "" "x 1 2 3" "Enter sequence of integers, each followed by a space: Error: Non-integer value 'x' received at index 0."
run_test_args "" "1 2 x 3" "Enter sequence of integers, each followed by a space: Error: Non-integer value 'x' received at index 2."
run_test_args "lots of args" "" "Usage: ./inversioncounter [slow]"
run_test_args "average" "" "Error: Unrecognized option 'average'."
run_test_args "" "" "Enter sequence of integers, each followed by a space: Error: Sequence of integers not received."
run_test_args "" "  " "Enter sequence of integers, each followed by a space: Error: Sequence of integers not received."
*/




    if(option == "slow"){
        
        int num_values = (int)values.size();
        int* arr = new int[num_values];
        for(int i =0;i<num_values;i++)
            arr[i]=values[i];
        cout<<"Number of inversions: "<<count_inversions_slow(arr, num_values)<<endl;
        delete[]arr;
        return 0;
    }

    

     int num_values = (int)values.size();

     if(num_values==0){
         cerr<<"Error: Sequence of integers not received."<<endl;
         return 1;
     }
        int* arr = new int[num_values];
        for(int i =0;i<num_values;i++)
            arr[i]=values[i];
        cout<<"Number of inversions: "<<count_inversions_fast(arr,num_values)<<endl;
        delete[]arr;
        return 0;

}
